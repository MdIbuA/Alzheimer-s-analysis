import './App.css';
import AlzheimersDetectionSystem from '@/components/AlzheimersDetectionSystem';

function App() {
  return (
    <>
      <AlzheimersDetectionSystem />
    </>
  );
}

export default App;